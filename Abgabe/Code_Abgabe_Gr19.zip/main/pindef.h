#pragma once

// Eingaenge
#define PIN_BUTTON1 10
#define PIN_BUTTON2 11

#define PIN_PHOTO 2
#define PIN_HALL 3

#define PIN_TRIGGER 4
#define PIN_SWITCH 5


// Ausgaenge
#define PIN_LED_YELLOW 12
#define PIN_LED_GREEN 13

#define PIN_SERVO 9
